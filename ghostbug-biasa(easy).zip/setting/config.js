const fs = require('fs')

global.owner = "6289602541152"
global.ownername = "𝐆𝐡𝐨𝐬𝐭𝐍𝐞𝐭𝐢𝐳𝐞𝐧͢‎ "
global.footer = "_© 𝐆𝐡𝐨𝐬𝐭𝐍𝐞𝐭𝐢𝐳𝐞𝐧͢‎ "
global.status = true
global.versisc = "1.0.0"
global.access = '6289602541152'
global.rulese = `
⦉═━═━═━═━═━═━═━═━═━═━═━═⦊
╽Name: ${ownername} 💥
╿Owner: ${ownername} 💥
╽Version: ${versisc} (ONLY GABUT)
╿( SC BUG GABUT, GHOST NETIZEN )
╰═━═━═━═━═━═━═━═━═━═━═━⦊
╿*OWNER MENU 💥*
╽> .addprem
╿> .delprem
╽*BUG MENU 💥*
╿> .locaui
╽> .locacrash
╰═━═━═━═━═━═━═━═━═━═━═━⦊
`

//========= Setting Message =========//
global.msg = {
"error": "𝐄𝐫𝐫𝐨𝐫!!",
"success": "ཏིུ͢ཅ𝐒𝐮𝐜𝐜𝐞𝐞𝐝𝐞𝐝🦠͢ཞིུ", 
"wait": "ཏིུ͢ཅ𝐏𝐫𝐨𝐜𝐞𝐬𝐬𝐢𝐧𝐠🦠͢ཞིུ", 
"group": "𝐎𝐧𝐥𝐲 𝐢𝐧 𝐠𝐫𝐮𝐛",
"private": "𝐎𝐧𝐥𝐲 𝐢𝐧 𝐩𝐫𝐢𝐯𝐚𝐭𝐞", 
"admin": "𝐎𝐧𝐥𝐲 𝐚𝐝𝐦𝐢𝐧",
"adminbot": "𝐁𝐨𝐭 𝐧𝐨𝐭 𝐚𝐝𝐦𝐢𝐧!!",
"owner": "𝐂𝐚𝐧'𝐭 𝐩𝐫𝐨𝐜𝐞𝐬𝐬, 𝐨𝐧𝐥𝐲 𝐨𝐰𝐧𝐞𝐫!!", 
"prem": "𝐍𝐨𝐭 𝐚𝐜𝐜𝐞𝐬𝐬",
"developer": "𝐎𝐧𝐥𝐲 𝐝𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫",
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})